<template>
    <div class="settings container">settings</div>
</template>

<script>
export default {
    name: 'Settings'
}
</script>

<style>

</style>
