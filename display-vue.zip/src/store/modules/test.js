// const config = {
//     orderBy: '',
//     orderDirection: 'asc',
// };
// const defaultOptions = {
//     limit: 1,
//     orderBy: 'timestamp',
//     orderDirection: 'desc',
//     filter: {
//         field: 'category',
//         value: 'all'
//     }
// };
// const options = {
//     limit: 5,
//     filter: {
//         value: 'test'
//     }
// };

// const settings = {...defaultOptions, ...options, ...config} 

// console.log(settings)

// // Result
// const settings = {    
//     limit: 5,
//     orderBy: 'timestamp',
//     orderDirection: 'desc',
//     filter: {
//         field: 'category'
//         value: 'test'
//     }
// };