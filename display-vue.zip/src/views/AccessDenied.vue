<template>
    <div class="container">
        <p>Access Denied</p>
    </div>
</template>

<script>
export default {

}
</script>

<style>
</style>
